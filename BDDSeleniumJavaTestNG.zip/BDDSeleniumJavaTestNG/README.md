# seleniumJavaCucumberWeb
Automation testing framework using Selenium + Java + Cucumber with BDD style

 The site in this script and test cases is NOT affiliated with me.

How to Run :
1. Make sure Java is installed.
2. Run from terminal with command = ( mvn clean verify -Dtestng="testng.xml" -DEnv="prod" )
3. Report after run automation is in folder target/results/regression
